import AddProblemForm from "./Components/AddProblemForm";
import ProblemList from "./Components/ProblemList";
function App() {
  const [problems, setProblems] = useState([]);

  const handleProblemAdded = (newProblem) => {
    setProblems((prev) => [...prev, newProblem]);
  };

  return (
    <>
      <AddProblemForm onProblemAdded={handleProblemAdded} />
      {/* <ProblemList problems={problems} setProblems={setProblems} /> */}
    </>
  );
}
