// src/components/AddProblemForm.jsx
import { useState } from "react";
import { addProblem } from "../services/problemService";

function AddProblemForm({ onProblemAdded }) {
  const [title, setTitle] = useState("");

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const newProblem = await addProblem({ title });
      onProblemAdded(newProblem); // update parent state
      setTitle("");
    } catch (err) {
      console.error(err.message);
    }
  };

  return (
    <form onSubmit={handleSubmit}>
      <input
        value={title}
        onChange={(e) => setTitle(e.target.value)}
        placeholder="Problem title"
      />
      <button type="submit">Add</button>
    </form>
  );
}

export default AddProblemForm;
