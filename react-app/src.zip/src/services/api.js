// src/services/api.js
const BASE_URL = "http://localhost:8000";

export default BASE_URL;
